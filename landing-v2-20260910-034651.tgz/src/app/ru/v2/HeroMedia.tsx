'use client';

import { useEffect, useRef, useState } from 'react';

/**
 * Подложка первого экрана.
 *
 * Почему не просто <video> с двумя <source media="...">: атрибут media у
 * <source> внутри <video> браузеры игнорируют — спецификация его оттуда убрала.
 * Поэтому кадрирование выбираем в JS до того, как назначен src, и грузим
 * ровно один файл: телефон не тянет десктопный кадр и наоборот.
 *
 * preload="none" плюс постер фоном: первый экран рисуется мгновенно, само
 * видео (около мегабайта) догружается после.
 *
 * prefers-reduced-motion: зацикленное видео — это движение. Пользователю,
 * который просил его выключить, показываем только постер и ничего не грузим.
 * Остальная страница уже уважает эту настройку, первый экран не исключение.
 */
export function HeroMedia({ className, style }: { className?: string; style?: React.CSSProperties }) {
  const ref = useRef<HTMLVideoElement>(null);
  const [crop, setCrop] = useState<'16x9' | '9x16' | null>(null);
  const [motionOk, setMotionOk] = useState(true);

  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    setMotionOk(!reduce.matches);
    if (reduce.matches) return;

    const narrow = window.matchMedia('(max-width: 900px)');
    setCrop(narrow.matches ? '9x16' : '16x9');
  }, []);

  useEffect(() => {
    const v = ref.current;
    if (!v || !crop) return;
    // Назначаем источники только после выбора кадрирования — до этого момента
    // у элемента нет src, и лишний файл не скачивается.
    v.innerHTML = '';
    for (const [type, ext] of [['video/webm', 'webm'], ['video/mp4', 'mp4']] as const) {
      const s = document.createElement('source');
      s.type = type;
      s.src = `/landing/ru/hero-${crop}.${ext}`;
      v.appendChild(s);
    }
    // play() сразу после load() браузер отклоняет: данных ещё нет. Ждём
    // canplay — только тогда запуск имеет смысл.
    const start = () => void v.play().catch(() => {});
    v.addEventListener('canplay', start, { once: true });
    v.load();
    return () => v.removeEventListener('canplay', start);
  }, [crop]);

  const poster = `/landing/ru/hero-poster-${crop ?? '16x9'}.webp`;

  return (
    <video
      ref={ref}
      poster={poster}
      autoPlay={motionOk}
      muted
      loop
      playsInline
      preload="none"
      aria-hidden="true"
      className={className}
      style={style}
    />
  );
}
